package com.altimetrik.haccess.dao;

import com.altimetrik.haccess.model.User;

public interface UserDao {
	
	void save(User userInfo);
	
	User authenticate(String userInfo);
	
	void validateUser(User userInfo);
	
	

}
