package com.altimetrik.haccess.dto;

public class HealthCareTxnRequest {

	private String vendorMobileNo;
	private String customerMobileNo;
	private String otpValue;
	private double txnAmount;
	
	
	
	public String getOtpValue() {
		return otpValue;
	}
	public void setOtpValue(String otpValue) {
		this.otpValue = otpValue;
	}
	public double getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}
	public String getVendorMobileNo() {
		return vendorMobileNo;
	}
	public void setVendorMobileNo(String vendorMobileNo) {
		this.vendorMobileNo = vendorMobileNo;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	
	
		
}
