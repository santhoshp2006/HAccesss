package com.altimetrik.haccess.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.altimetrik.haccess.daoImpl.CustomerReportDaoImpl;
import com.altimetrik.haccess.dto.CustomerReportRequest;
import com.altimetrik.haccess.dto.CustomerReportResponse;
import com.altimetrik.haccess.dto.FileUploadRequest;
import com.altimetrik.haccess.dto.FileUploadResponse;
import com.altimetrik.haccess.model.CustomerReportSummary;
import com.altimetrik.haccess.util.HAccessConstants;

/**
 * Handles requests for the application file upload requests
 */
@Controller()
@RequestMapping("haccess/customerreports")
public class FileUploadController {

	@Autowired
	CustomerReportDaoImpl reportImp;


	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public @ResponseBody FileUploadResponse uploadFileHandler(FileUploadRequest request) {

		FileUploadResponse response = new FileUploadResponse();

		if (!request.getFile().isEmpty()) {
			try {
				byte[] bytes = request.getFile().getBytes();

				
				String rootPath = "D:\\Reports";
				File dir = new File(rootPath + File.separator + request.getCustomerMobileNumber());
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + request.getReportName());
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				System.out.println("Server File Location=" + serverFile.getAbsolutePath());

				if(updateReportToDB(request, serverFile.getAbsolutePath())){
					response.setStatus(HAccessConstants.SUCCESS_STRING);
				}else
					response.setStatus(HAccessConstants.FAILUIRE_STRING);
			} catch (Exception e) {
				response.setStatus(HAccessConstants.FAILUIRE_STRING);
				e.printStackTrace();
			}
		} else {
			response.setStatus(HAccessConstants.EMPTY_STRING);
		}

		return response;
	}
	
	@RequestMapping(value = "/loadCustomerReport", method = RequestMethod.POST)
	public @ResponseBody  CustomerReportResponse showCustomerReport(@RequestBody CustomerReportRequest request) {
		
		CustomerReportResponse response = new CustomerReportResponse();

		try {

			System.out.println("========="+request.getCustomerMobileNumber());
			List<CustomerReportSummary> summary = reportImp.getCustomerReport(request.getCustomerMobileNumber());

			response.setSummary(summary);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
		
	}

	private boolean updateReportToDB(FileUploadRequest request, String serverFile) {
		
		boolean isSuccess = Boolean.FALSE;
		
		try {

			CustomerReportSummary summary = new CustomerReportSummary();

			summary.setCustomerMobileNumber(request.getCustomerMobileNumber());

			summary.setVendorMobileNumber(request.getVendorMobileNumber());

			summary.setFilePath(serverFile);

			reportImp.save(summary);
			isSuccess = Boolean.TRUE;
		} catch(Exception e){
			e.printStackTrace();
		}
		return isSuccess;
	}

}
