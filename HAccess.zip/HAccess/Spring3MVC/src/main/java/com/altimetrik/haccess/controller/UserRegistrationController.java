package com.altimetrik.haccess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.altimetrik.haccess.daoImpl.UserDaoImpl;
import com.altimetrik.haccess.dto.UserRegistrationRequest;
import com.altimetrik.haccess.dto.UserRegistrationResponse;
import com.altimetrik.haccess.model.User;
import com.altimetrik.haccess.util.HAccessConstants;

@Controller
public class UserRegistrationController {
	

	
	@Autowired
	UserDaoImpl usrDaoImpl;
	
	@RequestMapping(value = "userRegistration", method = RequestMethod.POST)
	public @ResponseBody UserRegistrationResponse doUserRegistration(@RequestBody UserRegistrationRequest registrationRequest) {
		
		UserRegistrationResponse response = updateUserInfo(registrationRequest);
		
		return response;
		
	}

	private UserRegistrationResponse updateUserInfo(UserRegistrationRequest registrationRequest) {
		
		UserRegistrationResponse response=  new UserRegistrationResponse();
		
		try {
		
		User userInfo = new User();
		
		userInfo.setUserName(registrationRequest.getUserName());
		
		userInfo.setPassword(registrationRequest.getPassword());
		
		userInfo.setAathaarCardId(registrationRequest.getAathaarCardId());
		
		userInfo.setEmailId(registrationRequest.getEmailId());
		
		userInfo.setMobileNo(registrationRequest.getMobileNo());
		
		userInfo.setUserType(registrationRequest.getUserType());
		
		usrDaoImpl.save(userInfo);
		
		
		response.setStatus(HAccessConstants.SUCCESS_STRING);
		
		}catch(Exception e){
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
			e.printStackTrace();
		}
		
		
		return response;
	}

}
