package com.altimetrik.haccess.dto;

public class OTPResponse extends BaseResponse {
  
}
