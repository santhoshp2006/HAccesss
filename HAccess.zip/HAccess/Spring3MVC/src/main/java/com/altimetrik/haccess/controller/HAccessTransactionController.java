package com.altimetrik.haccess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.altimetrik.haccess.dto.HealthCareTxnRequest;
import com.altimetrik.haccess.dto.HealthCareTxnResponse;
import com.altimetrik.haccess.dto.OTPRequest;
import com.altimetrik.haccess.dto.OTPResponse;
import com.altimetrik.haccess.dto.PersonRechargeRequest;
import com.altimetrik.haccess.dto.PersonRechargeResponse;
import com.altimetrik.haccess.service.HAccessTxnService;
import com.altimetrik.haccess.util.HAccessConstants;

@Controller
@RequestMapping("/transaction")
public class HAccessTransactionController {

	@Autowired
	HAccessTxnService txnService;
	
	
	@RequestMapping(value = "/doHealthVendorTxn", method = RequestMethod.POST)
	public @ResponseBody HealthCareTxnResponse doHealthVendorTxn(@RequestBody HealthCareTxnRequest request) {
		HealthCareTxnResponse response = new HealthCareTxnResponse();
		try {
			
			return txnService.doTransferPersonToVendor(request);
		}catch (Exception e) {
			System.err.println("Exception is occured while transfering health record "  );
			e.printStackTrace();
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
		}
		return response;
	}
	
	
	@RequestMapping(value = "/doRecharge", method = RequestMethod.POST)
	public @ResponseBody PersonRechargeResponse doRecharge(@RequestBody PersonRechargeRequest request) {
		PersonRechargeResponse response = new PersonRechargeResponse();
		try {
			return txnService.doRecharge(request);
			
		}catch (Exception e) {
			System.err.println("Exception is occured while transfering health record "  );
			e.printStackTrace();
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
		}
		return response;
	}
	
	@RequestMapping(value = "/doGenerateOTP", method = RequestMethod.POST)
	public @ResponseBody OTPResponse doGenerateOTP(@RequestBody OTPRequest request) {  
		
		OTPResponse response = new OTPResponse();
		
		try {
			return txnService.doGenerateOTP(request);
			
		}catch (Exception e) {
			System.err.println("Exception is occured while transfering health record "  );
			e.printStackTrace();
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
		}
		return response;
		
	}
	
	
	
	
}
