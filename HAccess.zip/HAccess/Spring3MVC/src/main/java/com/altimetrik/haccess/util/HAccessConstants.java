package com.altimetrik.haccess.util;

public class HAccessConstants {
	
	public static String SUCCESS_STRING = "SUCCESS";
	
	public static String FAILUIRE_STRING = "FAILUIRE";
	
	public static String EMPTY_STRING = "EMPTY";

}
