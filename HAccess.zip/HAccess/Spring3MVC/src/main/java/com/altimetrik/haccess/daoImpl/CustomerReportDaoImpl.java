package com.altimetrik.haccess.daoImpl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.altimetrik.haccess.dao.CustomerReportDao;
import com.altimetrik.haccess.model.CustomerReportSummary;
import com.altimetrik.haccess.util.CustomHibernateDaoSupport;

@Repository
public class CustomerReportDaoImpl extends CustomHibernateDaoSupport  implements CustomerReportDao{

	@Override
	public void save(CustomerReportSummary reportSummary) {
		getHibernateTemplate().save(reportSummary);
		
	}

	@Override
	public List<CustomerReportSummary> getCustomerReport(String customerMobileNumber) {
		
		System.out.println("Customer No === "+customerMobileNumber);
		
		@SuppressWarnings("unchecked")
		List<CustomerReportSummary> list = getHibernateTemplate().find(
                "from CustomerReportSummary customerSummary where customerSummary.customerMobileNumber=?",customerMobileNumber
           );
	
		if(CollectionUtils.isNotEmpty(list)) {
			return  list;
		}
		return null;
		
	}	
	

}
