package com.altimetrik.haccess.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "HAccessUserInfo")			
public class User {
	
	private int id;
	
	private String userName;
	
	private String password;
	
	private String mobileNo;
	
	private String emailId;
	
	private String aathaarCardId;
	
	private double amount;
	
	private String userType;
 	
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "USER_ID", unique = true, nullable = false)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "USER_NAME", nullable = false, length = 10)
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Column(name = "PASSWORD", nullable = false, length = 10)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "MOBILE_NO",unique=true, nullable = false, length = 10)
	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Column(name = "EMAIL_ID", nullable = false, length = 20)
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Column(name = "AADHAAR_CARD",unique=true, nullable = false, length = 20)
	public String getAathaarCardId() {
		return aathaarCardId;
	}

	public void setAathaarCardId(String aathaarCardId) {
		this.aathaarCardId = aathaarCardId;
	}

	@Column(name = "AMOUNT",length = 20, nullable = false)
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Column(name = "USER_TYPE",length = 20, nullable = false)
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
	
	

}
