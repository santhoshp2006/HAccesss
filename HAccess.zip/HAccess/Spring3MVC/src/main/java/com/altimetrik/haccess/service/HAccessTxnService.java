package com.altimetrik.haccess.service;

import com.altimetrik.haccess.dto.HealthCareTxnRequest;
import com.altimetrik.haccess.dto.HealthCareTxnResponse;
import com.altimetrik.haccess.dto.OTPRequest;
import com.altimetrik.haccess.dto.OTPResponse;
import com.altimetrik.haccess.dto.PersonRechargeRequest;
import com.altimetrik.haccess.dto.PersonRechargeResponse;

public interface HAccessTxnService {

	
	public HealthCareTxnResponse doTransferPersonToVendor(HealthCareTxnRequest request);
	
	public PersonRechargeResponse doRecharge(PersonRechargeRequest request);

	public OTPResponse doGenerateOTP(OTPRequest request);
}
