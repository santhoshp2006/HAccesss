package com.altimetrik.haccess.serviceImpl;



import java.util.HashMap;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.altimetrik.haccess.service.SMSService;
import com.altimetrik.haccess.util.SInfiniSMSGateway;

@Service
public class SMSServiceImpl implements SMSService{
	
   public static HashMap<String, Integer> otpMap = new HashMap<String, Integer>();  
	
	@Override
	public void sendMessageWithOTP(String mobileNo, String message, String type) {
		Random ran = new Random();
		int otp= 100000 + ran.nextInt(900000);
		//smsDao.createMessage(mobileNo, otp, type);
		otpMap.put(mobileNo, otp);
		message =  "One Time password for HWallet Transaction is  :  " + otp;
		sendMessage(mobileNo, message);
	}	
	
	@Override
	public void sendMessage(String mobileNo, String message) {
		SInfiniSMSGateway smsGateWay = new SInfiniSMSGateway();
		smsGateWay.sendSMS(mobileNo, message);
	}
	

	@Override
	public boolean validateOTP(String mobileNo, int otpValue, String type) {
		return otpMap.get(mobileNo).equals(otpValue);
		//return smsDao.validateOTP(mobileNo, otpValue, type);
	}

	

	
	
	

}
