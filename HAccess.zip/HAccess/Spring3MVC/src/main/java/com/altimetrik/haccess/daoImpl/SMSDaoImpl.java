package com.altimetrik.haccess.daoImpl;



import com.altimetrik.haccess.dao.SMSDao;

public class SMSDaoImpl implements SMSDao{

	@Override
	public boolean createMessage(String mobileNo, int otp, String type) {
		
		return false;
	}

	@Override
	public boolean validateOTP(String mobileNo, int otp, String type) {
		return false;
	}

}
