package com.altimetrik.haccess.dto;

public class PersonRechargeResponse extends BaseResponse{

	private Double customerLimit;

	public Double getCustomerLimit() {
		return customerLimit;
	}

	public void setCustomerLimit(Double customerLimit) {
		this.customerLimit = customerLimit;
	}
	
}
