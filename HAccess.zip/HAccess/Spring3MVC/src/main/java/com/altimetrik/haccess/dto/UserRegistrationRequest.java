package com.altimetrik.haccess.dto;

public class UserRegistrationRequest {
	
	private String userName;
	
	private String password;
	
	private String confirmpassword;
	
	private String mobileNo;
	
	private String emailId;
	
	private String aathaarCardId;
	
	private String userType;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAathaarCardId() {
		return aathaarCardId;
	}

	public void setAathaarCardId(String aathaarCardId) {
		this.aathaarCardId = aathaarCardId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	
	
}
