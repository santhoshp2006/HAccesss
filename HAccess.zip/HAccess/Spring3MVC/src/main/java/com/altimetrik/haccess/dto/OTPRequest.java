package com.altimetrik.haccess.dto;

public class OTPRequest {

	private String customerMobileNo;

	public String getCustomerMobileNo() {
		return customerMobileNo;
	}

	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	
}
