package com.altimetrik.haccess.dto;

public class HealthCareTxnResponse extends BaseResponse {
	
	
	private Double customerLimit;
	
	private Double vendorLimit;

	public Double getCustomerLimit() {
		return customerLimit;
	}

	public void setCustomerLimit(Double customerLimit) {
		this.customerLimit = customerLimit;
	}

	public Double getVendorLimit() {
		return vendorLimit;
	}

	public void setVendorLimit(Double vendorLimit) {
		this.vendorLimit = vendorLimit;
	}
	
	
	
	
}
