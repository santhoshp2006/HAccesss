package com.altimetrik.haccess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.altimetrik.haccess.daoImpl.UserDaoImpl;
import com.altimetrik.haccess.dto.LoginRequest;
import com.altimetrik.haccess.dto.LoginResponse;
import com.altimetrik.haccess.model.User;
import com.altimetrik.haccess.util.HAccessConstants;

@Controller
public class LoginController {
	
	
	@Autowired
	UserDaoImpl usrDaoImpl;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public @ResponseBody LoginResponse doLogin(@RequestBody LoginRequest loginRequest) {
		
		LoginResponse response = validateLoginUser(loginRequest);
		
		return response;
		
	}
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public @ResponseBody LoginResponse doLoginaaa(@RequestBody LoginRequest loginRequest) {
		
		LoginResponse response = validateLoginUser(loginRequest);
		
		return response;
		
	}


	private LoginResponse validateLoginUser(LoginRequest loginRequest) {
		
		LoginResponse response = new LoginResponse();
			
			
		User user = usrDaoImpl.authenticate(loginRequest.getUserName());
		
		if(user != null && user.getPassword().equals(loginRequest.getPassword())) {
			response.setStatus(HAccessConstants.SUCCESS_STRING);
			
			response.setAmount(user.getAmount());
			
			response.setEmailId(user.getEmailId());
			
			response.setMobileNo(user.getMobileNo());
			response.setUserName(user.getUserName());
		}else {
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
		}
		
		return response;
	}
}
