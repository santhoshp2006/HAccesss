package com.altimetrik.haccess.daoImpl;



import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.altimetrik.haccess.dao.HAccessTxnDao;
import com.altimetrik.haccess.model.User;
import com.altimetrik.haccess.util.CustomHibernateDaoSupport;

@Repository
public class HAccessTxnDaoImpl extends CustomHibernateDaoSupport  implements HAccessTxnDao{

	@Override
	@SuppressWarnings("unchecked")
	public Double[] doTransferPersonToVendor(User customerUser,
			User healthVendor) {
		
		List<User> userList = getHibernateTemplate().find(
                "from User user where user.mobileNo=?",customerUser.getMobileNo()
           );
		
		List<User> healthVendorList = getHibernateTemplate().find(
                "from User user where user.mobileNo=?",healthVendor.getMobileNo()
           );
		
		Double [] customerVendorLimit = new Double [2]; 
		
		if(CollectionUtils.isNotEmpty(userList) ) {
			User user = userList.get(0);
			Double customerLimit = user.getAmount() - customerUser.getAmount();
			user.setAmount(customerLimit);
			getHibernateTemplate().update(user);
			customerVendorLimit[0] = customerLimit;
		}
		
		
		if(CollectionUtils.isNotEmpty(healthVendorList) ) {
			User vendor = healthVendorList.get(0);
			Double vendorLimit = customerUser.getAmount() + vendor.getAmount();
			vendor.setAmount(vendorLimit);
			getHibernateTemplate().update(vendor);
			customerVendorLimit[1] = vendorLimit ;
		}
		
		return customerVendorLimit;
	}

	@Override
	public Double doRecharge(User customerUser) {
		@SuppressWarnings("unchecked")
		List<User> userList = getHibernateTemplate().find(
                "from User user where user.mobileNo=?",customerUser.getMobileNo()
           );
		
		if(CollectionUtils.isNotEmpty(userList)) {
			User user = userList.get(0);
			Double customerLimit = customerUser.getAmount() + user.getAmount();
			user.setAmount(customerLimit);
			getHibernateTemplate().update(user);
			return customerLimit;
		}
		return null;
	}

}
