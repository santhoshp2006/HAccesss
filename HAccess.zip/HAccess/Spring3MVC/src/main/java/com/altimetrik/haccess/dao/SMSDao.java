package com.altimetrik.haccess.dao;

public interface SMSDao  {

	boolean createMessage (String mobileNo, int otp, String type);
	
	boolean validateOTP(String mobileNo, int otp, String type);
}
