package com.altimetrik.haccess.dto;

import java.util.List;

import com.altimetrik.haccess.model.CustomerReportSummary;

public class CustomerReportResponse {
	
	List<CustomerReportSummary> summary ;

	public List<CustomerReportSummary> getSummary() {
		return summary;
	}

	public void setSummary(List<CustomerReportSummary> summary) {
		this.summary = summary;
	}
	
	
	
	
}
