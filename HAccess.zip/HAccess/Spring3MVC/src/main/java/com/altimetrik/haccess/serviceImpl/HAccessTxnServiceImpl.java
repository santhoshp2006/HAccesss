package com.altimetrik.haccess.serviceImpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.haccess.dao.HAccessTxnDao;
import com.altimetrik.haccess.dto.HealthCareTxnRequest;
import com.altimetrik.haccess.dto.HealthCareTxnResponse;
import com.altimetrik.haccess.dto.OTPRequest;
import com.altimetrik.haccess.dto.OTPResponse;
import com.altimetrik.haccess.dto.PersonRechargeRequest;
import com.altimetrik.haccess.dto.PersonRechargeResponse;
import com.altimetrik.haccess.model.User;
import com.altimetrik.haccess.service.HAccessTxnService;
import com.altimetrik.haccess.service.SMSService;
import com.altimetrik.haccess.util.HAccessConstants;

@Service
public class HAccessTxnServiceImpl  implements HAccessTxnService{

	@Autowired
	SMSService smsService;
	
	@Autowired
	HAccessTxnDao txnDao;	
	
	
	@Override
	public HealthCareTxnResponse doTransferPersonToVendor(HealthCareTxnRequest request) {
		
		if(!smsService.validateOTP(request.getCustomerMobileNo(),Integer.valueOf(request.getOtpValue()), "TransferFund")){
			HealthCareTxnResponse response = new HealthCareTxnResponse();
			response.setStatus(HAccessConstants.FAILUIRE_STRING);
			return response;
		}
		
		User healthVendor = new User();
		
		healthVendor.setAmount(request.getTxnAmount());
		healthVendor.setMobileNo(request.getVendorMobileNo());
		User customerUser = new User();
		customerUser.setAmount(request.getTxnAmount());
		customerUser.setMobileNo(request.getCustomerMobileNo());
		
		
		Double amountlimit[] = txnDao.doTransferPersonToVendor(customerUser,healthVendor);
		
		smsService.sendMessage(request.getCustomerMobileNo(), "An Amount of Rs. " + request.getTxnAmount() + " has been debited from your HWallet" );
		HealthCareTxnResponse response = new HealthCareTxnResponse();
		response.setStatus(HAccessConstants.SUCCESS_STRING);
		response.setCustomerLimit(amountlimit[0]);
		response.setVendorLimit(amountlimit[1]);
		
		return response;
	}

	@Override
	public PersonRechargeResponse doRecharge(PersonRechargeRequest request) {
		User customerUser = new User();
		customerUser.setAmount(request.getTxnAmount());
		customerUser.setMobileNo(request.getMobileNo());
		Double customerLimit = txnDao.doRecharge(customerUser);
		PersonRechargeResponse response = new PersonRechargeResponse();
		response.setCustomerLimit(customerLimit);
		response.setStatus(HAccessConstants.SUCCESS_STRING);
		
		smsService.sendMessage(request.getMobileNo(), "An Amount of Rs. " + request.getTxnAmount() + " has been credited to your HWallet" );
		
		return response;
	}
	
	public OTPResponse doGenerateOTP(OTPRequest request){
		OTPResponse response = new OTPResponse();
		smsService.sendMessageWithOTP(request.getCustomerMobileNo(),"One Time password for HWallet Transaction is ",null);
		response.setStatus(HAccessConstants.SUCCESS_STRING);
		return response;
		
	}

}
