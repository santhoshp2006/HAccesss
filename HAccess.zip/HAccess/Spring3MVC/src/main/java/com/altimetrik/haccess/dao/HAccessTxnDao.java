package com.altimetrik.haccess.dao;

import com.altimetrik.haccess.model.User;

public interface HAccessTxnDao {

	Double[] doTransferPersonToVendor(User customerUser, User healthVendor);

	Double doRecharge(User customerUser);

	
}
