package com.altimetrik.haccess.daoImpl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.altimetrik.haccess.dao.UserDao;
import com.altimetrik.haccess.model.User;
import com.altimetrik.haccess.util.CustomHibernateDaoSupport;



@Repository
public class UserDaoImpl  extends CustomHibernateDaoSupport  implements UserDao {


	

	@Override
	public void save(User userInfo) {
		getHibernateTemplate().save(userInfo);
	}

	@Override
	public User authenticate(String userName) {
		
		List list = getHibernateTemplate().find(
                "from User user where user.userName=?",userName
           );
	
		if(CollectionUtils.isNotEmpty(list)) {
			
			return (User) list.get(0);
		}
		return null;
	}

	@Override
	public void validateUser(User userInfo) {
		
		
	}

}
