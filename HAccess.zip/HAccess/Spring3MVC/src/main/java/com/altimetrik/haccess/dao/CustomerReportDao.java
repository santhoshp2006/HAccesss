package com.altimetrik.haccess.dao;

import java.util.List;

import com.altimetrik.haccess.model.CustomerReportSummary;

public interface CustomerReportDao {
	
	void save(CustomerReportSummary reportSummary);
	
	List<CustomerReportSummary> getCustomerReport(String customerMobileNumber);
	
	

}
