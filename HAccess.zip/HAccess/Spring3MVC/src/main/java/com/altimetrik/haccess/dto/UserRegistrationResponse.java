package com.altimetrik.haccess.dto;

public class UserRegistrationResponse {
	
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
