package com.altimetrik.haccess.util;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class SInfiniSMSGateway {

	/* (non-Javadoc)
	 * @see com.altipay.module.alert.sms.SmsSender#sendSMS(java.lang.String, java.lang.String)
	 */
	public void sendSMS(final String msisdn, final String message) {
		// instantiate a new thread - async call
		new Thread(new Runnable() {

			@Override
			public void run() {
				// send SMS
				processAndSendSMS(msisdn, message);
			}

		}).start();

	}

	/**
	 * @param msisdn
	 * @param message
	 */
	private void processAndSendSMS(String msisdn, String message) {
		InputStream in = null;
		try{
			
			String url = "http://alerts.sinfini.com/api/web2sms.php?";
			String mobileNoParam = "to";
			String messageParam = "message";
			String senderParam = "sender";
			String workingkeyParam = "workingkey";
			String  workingKeyVal = "150241064659x447m422";
			String senderVal = "DAVSMS";
			
			StringBuilder buffer = new StringBuilder( url );
			buffer.append( workingkeyParam + "=" + URLEncoder.encode( workingKeyVal, "UTF-8" ));
			buffer.append( "&" + senderParam + "=" + URLEncoder.encode( senderVal, "UTF-8" ));
			buffer.append( "&" + messageParam + "="+ URLEncoder.encode( message, "UTF-8" ) );
			buffer.append( "&" + mobileNoParam + "=" + URLEncoder.encode( msisdn.trim(), "UTF-8" ));
			
			
			
			
//			System.out.println(buffer.toString());
			
			HttpURLConnection connection = (HttpURLConnection)new URL( buffer.toString() ).openConnection();
			/*ITOP issue no- 1371
			 * To avoid proxy error in admin screen during cash receipt
			 * */
			connection.setConnectTimeout(5000);
			connection.setReadTimeout(5000);
			in = connection.getInputStream();
			
			
			
			int ch = 0;
			buffer = new StringBuilder();
			
			while((ch = in.read())!=-1){
				buffer.append((char)ch);
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}
		}
	}
	
}
