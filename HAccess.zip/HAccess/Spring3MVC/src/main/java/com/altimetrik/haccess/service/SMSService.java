package com.altimetrik.haccess.service;

public interface SMSService {

	public void sendMessageWithOTP(String mobileNo, String message, String type);
	public void sendMessage(String mobileNo, String message);
	public boolean validateOTP(String mobileNo, int otpValue, String type);
	
}
