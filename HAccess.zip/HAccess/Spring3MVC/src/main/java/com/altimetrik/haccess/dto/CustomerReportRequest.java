package com.altimetrik.haccess.dto;

public class CustomerReportRequest {
	
	private String  customerMobileNumber;

	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}
	
	

}
