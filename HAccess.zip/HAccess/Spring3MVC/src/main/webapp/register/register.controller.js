﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('RegisterController', RegisterController);

    RegisterController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http',];
    function RegisterController(UserService, $location, $rootScope, FlashService, $http) {
        var vm = this;
        vm.register = register;

        function register() {
            vm.dataLoading = true;
            console.log(vm.user);
            $http({
    			method: "POST",
    			url:'/HAccess/registrations',
    			data: vm.user,
    		}).success(function(data, status, headers, config) {
				console.log("Data --->"+data);
			}).error(function(data, status, headers, config) {
				console.log("status--->"+status);
			});
            $location.path('/login');
        }
    }

})();
