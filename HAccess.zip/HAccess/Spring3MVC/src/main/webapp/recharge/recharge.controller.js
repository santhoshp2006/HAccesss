(function () {
    'use strict';

    angular
        .module('app')
        .controller('RechargeController', RechargeController);

    RechargeController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function RechargeController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
    	
   	 $scope.bank = ['ICICI','AXIS','HDFC','CITI UNION', 'Nepal SBI', 'Punjab National'],

     $scope.makePayment = function(){
   		 alert("payment Method");
   		 
   		 
   		$http({
			method: "POST",
			url:'/HAccess/registrations'
		}).success(function(data, status, headers, config) {
			console.log("Data --->"+data);
		}).error(function(data, status, headers, config) {
			console.log("status--->"+status);
		});
        $location.path('/login');
   	 }	
   	 
    	$scope.creditAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.debitAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.netBankAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.walletAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.prepaidAction = function(){
    		 $location.path('/payment');
    	};
    	
    }

})();
