(function () {
    'use strict';

    angular
        .module('app')
        .controller('CustomerController', CustomerController);

    CustomerController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function CustomerController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
        $scope.walletBal = function() {
        	alert("wallet Balance");
        	$location.path('/balance');
           /* $http({
    			method: "POST",
    			url:'/HAccess/registrations',
    			data: vm.user,
    		}).success(function(data, status, headers, config) {
				console.log("Data --->"+data);
			}).error(function(data, status, headers, config) {
				console.log("status--->"+status);
			});*/
        }
        
        $scope.walletRecharge = function() {
        	alert("wallet Recharge");
        	$location.path('/recharge');
           /* $http({
    			method: "POST",
    			url:'/HAccess/registrations',
    			data: vm.user,
    		}).success(function(data, status, headers, config) {
				console.log("Data --->"+data);
			}).error(function(data, status, headers, config) {
				console.log("status--->"+status);
			});*/
        }
        
        
        
        
    }

})();
