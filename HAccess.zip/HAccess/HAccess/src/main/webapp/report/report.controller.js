(function () {
    'use strict';

    angular
        .module('app')
        .controller('ReportController', ReportController);

    ReportController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function ReportController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
    
    	$scope.gridOptions = {
    	        enableSorting: true,
    	        paginationPageSizes: [25, 50, 75],
    	        paginationPageSize: 25,
    	        columnDefs: [
    	          { name:'Lab Request Date ', field: 'requestDate' },
    	          { name:'Lab Test Info', field: 'TestInfo'},
    	          { name:'Taken By', field: 'takenBy', enableCellEdit:false},
    	          { name:'lab Test Amount', field: 'testAmt', enableCellEdit:false},
    	          { name:'view/Download', field: 'Link', enableCellEdit:false}
    	        ],
    	        data : [      {
    	                           "requestDate": "01/12/2016 12:30PM",
    	                           "TestInfo": "Lipid Profile",
    	                           "takenBy": "Narayana scan Center",
    	                           "testAmt" : "500",
    	                           "Link" : "view/Download"
    	                       },
    	                       {
    	                           "requestDate": "05/12/2016 12:30PM",
    	                           "TestInfo": "Liver Function Test",
    	                           "takenBy": "Apollo scan Center",
    	                           "testAmt" : "300",
    	                           "Link" : "view/Download"
    	                       },
    	                       {
    	                           "requestDate": "07/12/2016 3:30PM",
    	                           "TestInfo": "ElctroLities",
    	                           "takenBy": "Sachin scan Center",
    	                           "testAmt" : "400",
    	                           "Link" : "view/Download"
    	                       },
    	                       {
    	                           "requestDate": "08/12/2016 5:30PM",
    	                           "TestInfo": "Fasting glucose",
    	                           "takenBy": "Murali scan Center",
    	                           "testAmt" : "20000",
    	                           "Link" : "view/Download"
    	                       },
    	                       {
    	                    	   "requestDate": "07/12/2016 3:30PM",
    	                           "TestInfo": "ElctroLities",
    	                           "takenBy": "Sachin scan Center",
    	                           "testAmt" : "400",
    	                           "Link" : "view/Download"
    	                       }
    	                   ]
    	      };
     
    }

})();
