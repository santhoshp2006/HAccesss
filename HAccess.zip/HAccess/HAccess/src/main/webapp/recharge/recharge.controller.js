(function () {
    'use strict';

    angular
        .module('app')
        .controller('RechargeController', RechargeController);

    RechargeController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function RechargeController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
    	
   	 $scope.bank = ['ICICI','AXIS','HDFC','CITI UNION', 'Nepal SBI', 'Punjab National'],

     $scope.makePayment = function(){
   		$rootScope.loginFormData = {};
   		 
   		 console.log("payment"+$scope.payment);
   		$http({
			method: "POST",
			url:'http://localhost:8080/HAccessApp/transaction/doRecharge',
			data : $scope.payment
		}).success(function(data, status, headers, config) {
			console.log("Data --->"+data);
			
			if(data.status == "SUCCESS"){
				alert("Your amount has been added successfully");
				$rootScope.loginFormData.amount = data.customerLimit;
				 $location.path('/customerhomepage');
			}else{
				alert("Transcation gets failed");
			}
			
			
		}).error(function(data, status, headers, config) {
			console.log("status--->"+status);
		});
       
   	 }	
   	 
    	$scope.creditAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.debitAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.netBankAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.walletAction = function(){
    		 $location.path('/payment');
    	};
    	
    	$scope.prepaidAction = function(){
    		 $location.path('/payment');
    	};
    	
    }

})();
