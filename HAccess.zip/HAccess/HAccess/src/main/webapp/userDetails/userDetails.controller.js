(function () {
    'use strict';

    angular
        .module('app')
        .controller('UserDetailsController', UserDetailsController);

    UserDetailsController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function UserDetailsController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
    
     $scope.makePayment = function(){
    	 
   		
   		$http({
			method: "POST",
			url:'/HAccess/registrations'
		}).success(function(data, status, headers, config) {
			console.log("Data --->"+data);
		}).error(function(data, status, headers, config) {
			console.log("status--->"+status);
		});
        $location.path('/login');
   	 }
     
    }

})();
