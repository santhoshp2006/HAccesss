﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$location', 'AuthenticationService', 'FlashService', '$rootScope', '$scope', '$http'];
    function LoginController($location, AuthenticationService, FlashService, $rootScope, $scope, $http) {
        var vm = this;

        vm.login = login;
        $rootScope.loginFormData = {};
        $rootScope.payment = {};

        (function initController() {
            // reset login status
            AuthenticationService.ClearCredentials();
        })();

        function login() {
            vm.dataLoading = true;
         
        	console.log("login Data --->"+$scope.loginForm);

        	var status = true;
        	
        	
        	$http({
    			method: "POST",
    			url:'http://localhost:8080/HAccessApp/login',
    			data: $scope.loginForm
    		}).success(function(data, status, headers, config) {
				console.log("Data --->"+data);
				if(data.status == "FAILUIRE"){
					alert("Invalid used login, Please try again");
				}else{
					$rootScope.loginFormData.amount = data.amount;
					$rootScope.payment.mobileNo = data.mobileNo;
					$rootScope.payment.userName = data.userName;
					$location.path('/customerhomepage');
				}
			}).error(function(data, status, headers, config) {
				console.log("status--->"+status);
			});
        	
        
            
        };
    }

})();
