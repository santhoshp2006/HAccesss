﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('RegisterController', RegisterController);

    RegisterController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http','$scope'];
    function RegisterController(UserService, $location, $rootScope, FlashService, $http, $scope) {

      	 $scope.type = ['CUSTOMER', 'VENDOR'],

        
        
       $scope.register =  function register() {
      		 
      		 console.log($scope.registerform);
      		 
            $http({
    			method: "POST",
    			url:'http://localhost:8080/HAccessApp/userRegistration',
    			data: $scope.registerform
    		}).success(function(data, status, headers, config) {
				console.log("Data --->"+data);
				
				if(data.status == 'SUCCESS'){
					 $location.path('/login');
				}else{
					alert("Registration failed due to invalid inputs ");
				}
			}).error(function(data, status, headers, config) {
				console.log("status--->"+status);
			});
           
        }
    }

})();
