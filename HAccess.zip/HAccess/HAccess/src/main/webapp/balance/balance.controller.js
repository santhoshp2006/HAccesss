(function () {
    'use strict';

    angular
        .module('app')
        .controller('BalanceController', BalanceController);

    BalanceController.$inject = ['UserService', '$location', '$rootScope', 'FlashService', '$http', '$scope'];
    function BalanceController(UserService, $location, $rootScope, FlashService, $http, $scope) {
      
    	$scope.gridOptions = {
    	        enableSorting: true,
    	        paginationPageSizes: [25, 50, 75],
    	        paginationPageSize: 25,
    	        columnDefs: [
    	          { name:'name', field: 'name' },
    	          { name:'mobile', field: 'mobile'},
    	          { name:'transcation Amount', field: 'tranAmt', enableCellEdit:false},
    	          { name:'transcation Date', field: 'tranDate', enableCellEdit:false},
    	          { name:'Vendar', field: 'vendar', enableCellEdit:false}
    	        ],
    	        data : [      {
    	                           "name": "RAFIK",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Narayana"
    	                       },
    	                       {
    	                           "name": "NARAYANAN",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Noble"
    	                       },
    	                       {
    	                           "name": "MURALI",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Noble"
    	                       },
    	                       {
    	                           "name": "SANTHOSH",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Noble"
    	                       },
    	                       {
    	                           "name": "XXXX",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Noble"
    	                       },
    	                       {
    	                           "name": "YYYY",
    	                           "mobile": "9887867857",
    	                           "tranAmt": "6868767",
    	                           "tranDate" : "12/12/2016",
    	                           "vendar" : "Noble"
    	                       }
    	                   ]
    	      };
    	
       
    }

})();
